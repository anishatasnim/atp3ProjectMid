var	express		= require('express');
var router		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var customerModel	= require.main.require('./models/customer-model');
var jobModel	= require.main.require('./models/job-model');


//Login
router.get('/',function(req,res){	
	console.log("Requested : Customer " +  req.session.email);
	var user ={
		email : req.session.email,
	};		
	res.render('customer/customerHome/index',{customer : user});
	
});

router.get('/ownInfo',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.user_email);
	console.log("Email ::"+email);
	customerModel.getByEmail(user,function(result){
		console.log(result);
		res.render('customer/customerHome/ownInfo',{user : result});
	});
});
router.get('/editProfile',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.user_email);
	console.log("Email ::"+email);
	customerModel.getByEmail(user,function(result){
		console.log(result);
		res.render('customer/customerHome/editProfile',{user : result});
	});
});
router.post('/editProfile',function(req,res){
console.log("post a jai")	
	var customer=
	{
		customer_fullname:req.body.fullname,
		customer_password:req.body.password,
		customer_address:req.body.address,
		customer_email:req.body.email,
		customer_contactno:req.body.contactno,

	}
	console.log(customer);
	customerModel.update(customer,function(status){
		if(status){
			console.log(status);
			res.render('customer/customerHome/editProfile');
		}
		else{
			res.send(unsuccessfull);
		}
	});
});
router.get('/job',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.user_email);
	console.log("Email ::"+email);
	customerModel.getByEmail(user,function(result){
		console.log(result);
		res.render('job/index',{user : result});
	});
});
router.post('/job',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};	
	customerModel.getByEmail(user,function(result){
		console.log(result);
		var job=
	{
		job_email:req.session.email,
		job_status:req.body.status,
		job_category:req.body.category,
		job_title:req.body.title,
		job_description:req.body.description,
		job_fee:req.body.fee,

	}
	console.log(job);
	jobModel.insertJob(job,function(status){
		if(status){
			console.log(status);
			res.render('job/index');
		}
		else{
			res.send("unsuccessfull");
		}
	});
		res.render('customer/customerHome/ownInfo',{user : result});
	});
	
});
router.get('/jobInfo',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.user_email);
	console.log("Email ::"+email);
	jobModel.getByEmail(user,function(result){
		console.log(result);
		res.render('job/jobInfo',{user : result});
	});
});





/*router.get('/Employee',function(req,res){		

	var results;

	employeeModel.getAllEmployee(function(results){
			if(results.length > 0){
				console.log(results);
				res.render('admin/adminHome/employees', {employeeList: results});
			}else{
				res.render('admin/adminHome/employees', {employeeList: results});
			}
		});	
	});


router.get('/addEmployee?',function(req,res){		
	res.render('admin/adminHome/addEmployee');		
	});

router.post('/addEmployee?',function(req,res){		
	var employee =
	{		
		employee_fullname: req.body.full_name,
		employee_password: req.body.password,
		employee_email: req.body.email,
		employee_contactno : req.body.contactno
		
	}
	employeeModel.insertEmployee(employee, function(status){
			if(status){
				employeeModel.getEmployeeId(employee,function(result){
					console.log(result);
					employee.user_id = result.user_id;
					employee.user_type = 'manager';
					employee.user_status = 'active';

					var user= 
					{
						user_id : employee.user_id,
						user_email : employee.employee_email,
						user_password : employee.employee_password,
						user_type : employee.user_type,
						user_status : employee.user_status
					}
					console.log(employee);
					console.log(user);
					loginModel.insertLogin(user,function(status){
						if(status){
							res.redirect('/admin/Employee');
						}
						else{
							res.send("Failed");
						}

					});

				});











				
			}else{
				res.redirect('/admin/addEmployee'+req.params.id);
			}
		});*/
	//});




module.exports = router;

