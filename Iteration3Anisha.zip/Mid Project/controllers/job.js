var express 	= require('express');
var router 		= express.Router();
var customerModel= require.main.require('./models/customer-model');
var jobModel= require.main.require('./models/job-model');

router.get('/', function(req, res){
	console.log('login page requested!');
	res.render('login/index');
});



/*router.post('/', function(req, res){
		
		var user ={
			user_email: req.body.user_email,
			user_name: req.body.user_name
		};

		console.log(user);

		jobModel.validate(user, function(status){
			if(status){
				loginModel.getType(user, function(result){
					console.log(result);
					var type = JSON.stringify(result.user_type.toString());
					var status = JSON.stringify(result.account_status.toString());

					if(type=='"customer"' && status=='"active"'){
                        req.session.email = req.body.user_email;						
						res.redirect("/customer");
					}		


					else{
						res.send('CUSTOMER');
					}
				});
				
			}else{
				
			}
		});
});
//Registration
/*router.get('/Employee',function(req,res){		

	var results;

	employeeModel.getAllEmployee(function(results){
			if(results.length > 0){
				console.log(results);
				res.render('admin/adminHome/employees', {employeeList: results});
			}else{
				res.render('admin/adminHome/employees', {employeeList: results});
			}
		});	
	});*/


router.get('/job',function(req,res){		
	res.render('login/index');		
	});
router.get('/jobInfo',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.user_email);
	console.log("Email ::"+email);
	jobModel.getByEmail(user,function(result){
		console.log(result);
		res.render('job/jobInfo',{user : result});
	});
});

/*router.post('/job',function(req,res){		
	var job =
	{		
		job_status: req.body.status,
		job_category: req.body.category,
		job_title: req.body.title,
		job_description : req.body.description,
		job_fee : req.body.fee
	}
	// customerModel.insertCustomer(customer, function(status){
	// 		if(status){
				customerModel.getCustomerId(customer,function(result){
					console.log(result);
					customer.user_id = result.user_id;
					// customer.user_type = 'customer';
					// customer.user_status = 'active';

					var job= 
					{
						job_id : job.id,
						job_status : job.status,
						job_category : job.category,
						job_title : job.title,
						job_decription : job.description,
						job_fee : job.fee
					}
					console.log(job);
					// console.log(user);
					loginModel.insertLogin(job,function(status){
						if(status){
							res.redirect('login/index');
						}
						else{
							res.send("Failed");
						}

					});

				});
				
	// 		}else{
	// 			res.redirect('/registration'+req.params.id);
	// 		}
	// 	});
	 });*/

module.exports = router;
