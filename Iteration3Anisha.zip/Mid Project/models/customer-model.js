var db = require('./db');

module.exports ={
	
	
	getAllCustomer:function(callback){
		var sql = "select * from customer";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	insertCustomer: function(customer, callback){
		var sql = "insert into customer values(?,?,?,?,?,?)";
		db.execute(sql, [null, customer.customer_fullname,customer.customer_email, customer.customer_password,customer.customer_contactno,customer.customer_address], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},

	getCustomerId:function(customer, callback){
		var sql = "select user_id from customer where user_email=? and user_password=?";
		db.getResult(sql, [customer.customer_email, customer.customer_password], function(results){
			if(results.length > 0){
				callback(results[0]); 
			}else{
				callback(null);
			}
		});
	},
	getByEmail:function(customer, callback){
		var sql = "select * from customer where user_email=? ";
		var sqlPrint = "select * from customer where user_email="+customer.email+" ";
		console.log(sqlPrint);
		db.getResult(sql, [customer.email], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	getById : function(id, callback){
		var sql = "select * from customer where id=?";
		db.getResult(sql, [id], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	update:function(customer,callback){
		var sql="UPDATE `customer` SET `user_name`=?,`user_email`=?,`user_password`=?,`user_phoneno`=?,`user_address`=? WHERE user_email=?";
		var sqlPrint = "update customer set user_name="+customer.customer_fullname+", user_password="+customer.customer_password+", user_phoneno="+customer.customer_contactno+", user_address="+customer.customer_address+" where user_email="+customer.customer_email+";";
		console.log(sqlPrint);
		db.execute(sql,[customer.customer_fullname,customer.customer_email,customer.customer_password,customer.customer_contactno,customer.customer_address,customer.customer_email],function(status){
            if(status){
				callback(true);
			}else{
				callback(false);
			}
		})
	},
	changePass:function(customer,callback){
		var sql="UPDATE `customer` SET `user_password`=? WHERE user_email=?";
		var sqlPrint = "update customer set  user_password="+customer.customer_password+" where user_email="+customer.customer_email+";";
		console.log(sqlPrint);
		db.execute(sql,[customer.customer_password,customer.customer_email],function(status){
            if(status){
				callback(true);
			}else{
				callback(false);
			}
		})
	}
}
